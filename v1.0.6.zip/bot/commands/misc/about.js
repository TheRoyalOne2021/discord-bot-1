module.exports = {
  commands: ['about', 'info'],
  permissionError: 'You need more permissions to run this command',
  minArgs: 0,
  maxArgs: 0,
  callback: (message, arguments, text) => {

   message.reply("\n:robot:- `Hello! I am a multipurpose discord bot in progress.`\n"
            + 'I am powered by Discord.js/Commando and coded in javascript.\n'
            + 'If you know javascript and nodejs and would like to improve me, check my code in\n'
            + '<https://github.com/TheRoyalOne2021/discord-bot-1>\n'
            + 'Feedback and feature requests go in\n'
            + '<https://github.com/TheRoyalOne2021/issues>'
            + 'To contact me, add my discord:\n'
            + '<TheRoyalOne#3275>')
  },
  permissions: 'SEND_MESSAGES',
  requiredRoles: [],
}

