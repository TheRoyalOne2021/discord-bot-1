module.exports = {
  commands: ['random'],
  permissionError: 'You need more permissions to run this command',
  maxArgs: 0,
  permissions: 'SEND_MESSAGES',
  callback: (message, arguments, text) => {
var random = Math.floor(Math.random() * 999999) + 1;
  message.reply(` ${random} `);
 },
 }
