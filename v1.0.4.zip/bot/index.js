const path = require('path')
const rpc = require('discord-rpc')
const fs = require('fs')
const config = require('./config.json')
const scalingChannels = require('./scaling-channels')
const {
Client,
Intents
} = require('discord.js');

const client = new Client({
intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MEMBERS, Intents.FLAGS.GUILD_MESSAGES]
});

client.setMaxListeners(0);

client.on('ready', () => {
console.log('Bot is logged in!');
    client.user.setPresence({
        status: 'idle',
        activity: {
            name: 'Discord',
            details: 'https://discord.gg/5HeCfqfcj6',
            type: 'WATCHING',
            url: 'https://discord.gg/5HeCfqfcj6'
        }
    });
});

client.on('guildMemberAdd', (member) => {
    console.log(member)
});

client.on('guildMemberAdd', member => {
    member.send(" Welcome! Please Verify at #verify and check #rules https://tenor.com/view/star-wars-baby-yoda-the-mandalorian-welcome-wave-gif-16179355 ");
});

client.on('guildMemberRemove', member => {
    member.send("Goodbye *:(* sorry to see you leave so soon https://tenor.com/view/sad-cry-crying-tears-broken-gif-15062040 ");
});

  scalingChannels(client)

  const baseFile = 'command-base.js'
  const commandBase = require(`./commands/${baseFile}`)

  const readCommands = (dir) => {
    const files = fs.readdirSync(path.join(__dirname, dir))
    for (const file of files) {
      const stat = fs.lstatSync(path.join(__dirname, dir, file))
      if (stat.isDirectory()) {
        readCommands(path.join(dir, file))
      } else if (file !== baseFile) {
        const option = require(path.join(__dirname, dir, file))
        commandBase(client, option)
      }
    }
  }

  readCommands('commands')

client.login(config.token)

