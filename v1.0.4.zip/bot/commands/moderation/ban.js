module.exports = {
  commands: ['ban'],
  maxArgs: 1,
  permissionError: 'You do not have permission to use this command.',
  permissions: 'BAN_MEMBERS',
  callback: (message, arguments, text) => {

  if (!message.guild) return;

    const user = message.mentions.users.first();

    if (user) {

      const member = message.guild.members.resolve(user);
      
      if (member) {
        member
          .mute({
            reason: 'They were disrespectful!',
          })
          .then(() => {
            message.channel.send(`Successfully banned ${user.tag} `);
          })
          .catch(err => {
            message.channel.send('You do not have permissions to ban');
            console.error(err);
          });
      } else {
        message.channel.send("That user doesn't exist in this Guild!");
      }
    } else {
      message.channel.send("No user was mentioned!");
    }
}
}
