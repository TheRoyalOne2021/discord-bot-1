module.exports = {
  commands: ['date', 'getdate', 'datetime'],
    permissions: 'SEND_MESSAGES',
  permissionError: 'You need more permissions to run this command',
  minArgs: 0,
  maxArgs: 0,
  description: 'show the current date and time "EST only for now" ',
  callback: (message, arguments, text) => {
  var date = new Date();
  const WeekDay = date.getDay() + 1;
let a;

switch(WeekDay){
    case 1: 
        a = 'Sun';
        break;
    case 2:
        a = 'Mon';
        break;
    case 3:
        a = 'Tues';
        break;
    case 4:
        a = 'Wed';
        break;
    case 5:
        a = 'Thurs';
        break;
    case 6:
        a = 'Fri';
        break;
    case 7:
        a = 'Sat';
        break;
        }
        
        const Month = date.getMonth() + 1;
let b;

switch(Month){
    case 1: 
        b = 'January';
        break;
    case 2:
        b = 'February';
        break;
    case 3:
        b = 'March';
        break;
    case 4:
        b = 'April';
        break;
    case 5:
        b = 'May';
        break;
    case 6:
        b = 'June';
        break;
    case 7:
        b = 'July';
        break;
        case 8:
        b = 'August';
        break;
        case 9:
        b = 'September';
         break;
        case 10:
        b = 'October';
         break;
        case 11:
        b = 'November';
         break;
        case 12:
        b = 'December';
         break;
}

        const Day = date.getDate();
let c;

switch(Day){
    case 1: 
        c = '1st';
        break;
    case 2:
        c = '2nd';
        break;
    case 3:
        c = '3rd';
        break;
    case 4:
        c = '4th';
        break;
    case 5:
        c = '5th';
        break;
    case 6:
        c = '6th';
        break;
    case 7:
        c = '7th';
        break;
        case 8:
        c = '8th';
        break;
        case 9:
        c = '9th';
         break;
        case 10:
        c = '10th';
         break;
        case 11:
        c = '11th';
         break;
        case 12:
        c = '12th';
         break;
         case 13:
        c = '13th';
         break;
         case 14:
        c = '14th';
         break;
         case 15:
        c = '15th';
         break;
         case 16:
        c = '16th';
         break;
         case 17:
        c = '17th';
         break;
         case 18:
        c = '18th';
         break;
         case 19:
        c = '19th';
         break;
         case 20:
        c = '20th';
         break;
         case 21:
        c = '21st';
         break;
         case 22:
        c = '22nd';
         break;
         case 23:
        c = '23rd';
         break;
         case 24:
        c = '24th';
         break;
         case 25:
        c = '25th';
         break;
         case 26:
        c = '26th';
         break;
         case 27:
        c = '27th';
         break;
         case 28:
        c = '28th';
         break;
         case 29:
        c = '29th';
         break;
         case 30:
        c = '30th';
         break;
         case 31:
        c = '31st';
         break;
}

const Year = date.getFullYear();

var Hour = date.getHours();
var AMPM = Hour >= 12 ? 'PM' : 'AM';
var Minute = date.getMinutes();
var Second = date.getSeconds();
Hour = (Hour % 12) || 12;
Minute = Minute < 10 ? '0'+Minute : Minute;
Second = Second < 10 ? '0'+Second : Second;


   message.reply(`Date: ${a}, ${b} ${c}, ${Year}, ${Hour}:${Minute}:${Second} ${AMPM}`);
    }
}
