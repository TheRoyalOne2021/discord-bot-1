const path = require('path')
const rpc = require('discord-rpc')
const fs = require('fs')
const config = require('./assets/config.json')
const env = require('./assets/.env')
const welcome = require('./assets/gifs/welcome-gifs.json')
const goodbye = require('./assets/gifs/goodbye-gifs.json')
const scalingChannels = require('./assets/scaling-channels')
const {Client, Intents, MessageEmbed} = require('discord.js');
const { CommandoClient } = require('discord.js-commando');
const client = new CommandoClient({
  intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MEMBERS, Intents.FLAGS.GUILD_MESSAGES],
});

client.setMaxListeners(0);

client.on('ready', () => {
    var a = new Date();
console.log(a.toLocaleString());
console.log('Bot successfully logged in!');

client.user.setPresence({
        status: 'online',
        activity: { 
            name: ` ${client.guilds.cache.size} servers`,
            details: 'https://discord.gg/5HeCfqfcj6',
            type: 'COMPETING',
            url: 'https://discord.gg/5HeCfqfcj6'
        }
    });
});

client.on('disconnect', (event) => {
  logger.error(`[DISCONNECT] Disconnected with code ${event.code}.`);
  process.exit(0);
});

client.on('error', (err) => logger.error(err));
    
    client.on('message', message => {
const prefix = '$setactivity';
    if (message.content.startsWith(prefix)) {
  if (!message.guild) {
  return;
  } else {
        const args = message.content.slice(prefix.length).trim(` ${message.content}`);
        if (message.member.hasPermission('MANAGE_GUILD')) {
        const presence = args;
        message.reply(`Status set to "Playing ${presence}" successfully `);
        client.user.setPresence({
        status: 'online',
        activity: { 
            name: ` ${presence} `,
            details: 'https://discord.gg/5HeCfqfcj6',
            type: 'PLAYING',
            url: 'https://discord.gg/5HeCfqfcj6'
}
 });
  } else {
  if (!message.member.hasPermission('MANAGE_GUILD')) {
  message.reply('You do not have permission to use this command');
}
 }
  }
   }
   });
   
   client.on('message', message => {
const prefix = '$resetactivity';
    if (message.content.startsWith(prefix)) {
    if (!message.guild) {
  return;
  } else {
        if (message.member.hasPermission('MANAGE_GUILD')) {
client.user.setPresence({
        status: 'online',
        activity: { 
            name: ` ${client.guilds.cache.size} servers`,
            details: 'https://discord.gg/5HeCfqfcj6',
            type: 'COMPETING',
            url: 'https://discord.gg/5HeCfqfcj6'
}
 });
 } else {
  if (!message.member.hasPermission('MANAGE_GUILD')) {
  message.reply('You do not have permission to use this command');
}
 }
  }
   }
    });
  
    
          client.on('message', message => {
if (!message.guild) {
return;
} else {          
if(message.content === "$setstatus online") {
if (message.member.hasPermission('MANAGE_GUILD')) {
message.reply('Status set to online');
client.user.setStatus('online');
}
  if (!message.member.hasPermission('MANAGE_GUILD')) {
  message.reply('You do not have permission to use this command');
}
 }
  }
   });

client.on('message', message => {
if (!message.guild) {
return;
} else {
if(message.content === "$setstatus idle") {
if (message.member.hasPermission('MANAGE_GUILD')) {
 message.reply('Status set to idle');
client.user.setStatus('idle');
}
  if (!message.member.hasPermission('MANAGE_GUILD')) {
  message.reply('You do not have permission to use this command');
}
 }
  }
   });
  
         client.on('message', message => {
if (!message.guild) {
return;
} else {
if(message.content === "$setstatus dnd") {
 if (message.member.hasPermission('MANAGE_GUILD')) {
 message.reply('Status set to dnd');
client.user.setStatus('dnd');
}
  if (!message.member.hasPermission('MANAGE_GUILD')) {
  message.reply('You do not have permission to use this command');
}
 }
  }
   });

client.on('message', message => {
if (!message.guild) {
return;
} else {         
if(message.content === "$setstatus invisible") {
if (message.member.hasPermission('MANAGE_GUILD')) {
message.reply('Status set to invisible');
client.user.setStatus('invisible');
}
if (!message.member.hasPermission('MANAGE_GUILD')) {
message.reply('You do not have permission to use this command');
}
 }
  }
   });
  
  client.on("message", message => {
if (message.content === "$servercount") {
const embed = new MessageEmbed() 
.setTitle(`${client.user.tag} is in ${client.guilds.cache.size} servers`)
.addField(`Total Member Count: ${client.users.cache.size}`, `Requested By <@${message.author.id}>`)
.setTimestamp();
message.channel.send(embed);
}
  });
  
client.on('guildMemberAdd', (member) => {
    console.log(member)
});

client.on('guildMemberAdd', member => {
var b = welcome[Math.floor(Math.random() * welcome.length)];
var serverIcon = member.guild.iconURL();
    const embed = new MessageEmbed()
      .setAuthor(['710615575419682848'].includes(client.user.id) ? 'Admin' : '')
      .setTitle(member.user.tag)
      .setDescription(' Welcome! Please Verify at #verify and check #rules ')
      .setThumbnail(serverIcon)
      .setImage(b)
      .setFooter(`Server: ${member.guild.name}`)
      if (['710615575419682848'].includes(client.user.id)) {
          embed.setColor('#ff0f00')
      } else {
          embed.setColor('RANDOM')
      }
      try {
       member.send(embed);
      } catch (e) {
        return;
}
 });

client.on('guildMemberRemove', member => {
var c = goodbye[Math.floor(Math.random() * goodbye.length)];
    var serverIcon = member.guild.iconURL();
    const embed = new MessageEmbed()
      .setAuthor(['710615575419682848'].includes(client.user.id) ? 'Admin' : '')
      .setTitle(member.user.tag)
      .setDescription(' Goodbye :( sorry to see you leave so soon ')
      .setThumbnail(serverIcon)
      .setImage(c)
      .setFooter(`Server: ${member.guild.name}`)
      if (['710615575419682848'].includes(client.user.id)) {
          embed.setColor('#ff0f00')
      } else {
          embed.setColor('RANDOM')
      }
      try {
       member.send(embed);
      } catch (e) {
        return;
}
 });
 
   //help command notification
     client.on('message', message => {
    if(message.content === "$help") {
    if (message.guild) {
    message.channel.send(`I sent you a dm with help ${message.author.tag}!`)
    } else {
    if (!message.guild) {
    message.author.send(`Help is on the way`)
}
 }
  }
   });
    
    //server count command
     client.on('message', message => {
     let embedservercount = new MessageEmbed()
.setTitle("Server Count Command: ")
.setDescription("**Outputs the number of servers the bot is currently in**")
.setColor("RANDOM")
.setFooter("usage: $servercount")
    if(message.content === "$help") {
message.author.send(embedservercount)
} else {
if(message.content === "$help servercount") {
message.author.send(embedservercount)
}
 }
  });
 
    //setstatus commands
    client.on('message', message => {
    if(message.content === "$help") {
    let embedsetstatus = new MessageEmbed()
.setTitle("Set Status Command: ")
.setDescription("**Set the bots' status, required arguments: online, idle, dnd, or invisible (nothing will happen if no arguments are set)**")
.setColor("RANDOM")
.setFooter("usage example: $setstatus idle (requires manage server permissions)")
message.author.send(embedsetstatus)
}
 });
 
       client.on('message', message => {
    if(message.content === "$help") {
    let embedsetpresence = new MessageEmbed()
.setTitle("Set Activity Command: ")
.setDescription("**Set a custom activity for the bot (requires manage server permissions)**")
.setColor("RANDOM")
.setFooter("usage example: $setpresence Discord, Output would be: Playing Discord")
message.author.send(embedsetpresence)
}
 });

       client.on('message', message => {
    if(message.content === "$help") {
    let embedresetpresence = new MessageEmbed()
.setTitle("Reset Activity Command: ")
.setDescription("**Reset the bots' activity to default(default shows how many servers the bot is in) (requires manage server permissions)**")
.setColor("RANDOM")
.setFooter("usage: $resetpresence")
message.author.send(embedresetpresence)
}
 });
 
      //info commands 
      client.on('message', message => {
    let embedinfo = new MessageEmbed()
.setTitle("Info Commands: ")
.setDescription(" **avatar, about** ")
.setColor("RANDOM")
.setFooter("type $help <commandname> to see info on a specific command")
 if (message.guild) {
if(message.content === "$help info") {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedinfo)
} else {
 if(message.content === "$help") {
message.author.send(embedinfo)
}
 }
  }
    });
 
   client.on('message', message => {
if(message.content === "$help invites") {
 let embedinviterank = new MessageEmbed()
.setTitle("Invite Rank Command: ")
.setDescription("**shows top ten users with the most invites in your server**")
.setColor("RANDOM")
.setFooter("usage: $invites, $inviterank, $topinvites")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedinviterank)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedinviterank)
}
 }
  }
   });
   
  client.on('message', message => {
    if(message.content === "$help avatar") {
    let embedavatar = new MessageEmbed()
.setTitle("Avatar Command: ")
.setDescription(" **Displays a mentioned users avatar,if no user is mentioned command will show message authors' avatar** ")
.setColor("RANDOM")
.setFooter("usage: $avatar <@user>")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedavatar)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way ${message.author.tag}`)
  message.author.send(embedavatar)
}
 }
  }
   });
 
  client.on('message', message => {
    if(message.content === "$help about") {
    let embedabout = new MessageEmbed()
.setTitle("About Command: ")
.setDescription(" **Show info about the bot, and the creators' contact info** ")
.setColor("RANDOM")
.setFooter("usage: $info, $about")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedabout)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedabout)
}
 }
  }
   });
 
    //moderation commands
    client.on('message', message => {
    let embedmod = new MessageEmbed()
.setTitle("Moderation Commands: ")
.setDescription(" **kick, ban, mute, unmute, rmchannel(use with caution), clear(use with caution), inviterank, newticket** ")
.setColor("RANDOM")
.setFooter("type $help <commandname> to see info on a specific command")
 if (message.guild) {
if(message.content === "$help mod") {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedmod)
} else {
 if(message.content === "$help") {
message.author.send(embedmod)
} 
 }
  }
   });
    
 client.on('message', message => {
if(message.content === "$help kick") {
  let embedkick = new MessageEmbed()
.setTitle("Kick Command:")
.setDescription(" **Kicks a mentioned user, required arguments: $kick <@user> ** ")
.setColor("RANDOM")
.setFooter("requires permission to kick members")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedkick)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedkick)
}
 }
  }
   });
 
  client.on('message', message => {
if(message.content === "$help ban") {
  let embedban = new MessageEmbed()
.setTitle("Ban Command: ")
.setDescription(" **Bans a mentioned user, required arguments: $ban <@user> ** ")
.setColor("RANDOM")
.setFooter("requires permission to ban members")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedban)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedban)
}
 }
  }
   });
 
  client.on('message', message => {
if(message.content === "$help mute") {
  let embedmute = new MessageEmbed()
.setTitle("Mute Command: ")
.setDescription("**mutes a mentioned user, requires role called 'muted' and role permissions set** ")
 .addField("usage: $mute <@user> ")
.setColor("RANDOM")
.setFooter("requires permission to timeout members")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedmute)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedmute)
}
 }
  }
   });
 
   client.on('message', message => {
if(message.content === "$help unmute") {
  let embedmute = new MessageEmbed()
.setTitle("Unmute Command: ")
.setDescription("**unmutes a mentioned user, requires role called 'muted' and role permissions set** ")
 .addField("usage: $unmute <@user> ")
.setColor("RANDOM")
.setFooter("requires permission to timeout members")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedunmute)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedunmute)
}
 }
  }
   });
 
   client.on('message', message => {
if(message.content === "$help clear") {
  let embedclear = new MessageEmbed()
.setTitle("Clear Command: ")
.setDescription("**Clear 100+ messages from a focused channel(cannot be undone, use with caution)** ")
 .addField("usage: $clear, $cc, $clearchannel, $sudo apt clean")
.setColor("RANDOM")
.setFooter("requires permission to manage messages")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedclear)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedclear)
}
 }
  }
   });
   client.on('message', message => {
if(message.content === "$help rmchannel") {
  let embedchanneldel = new MessageEmbed()
.setTitle("Rmchannel Command: ")
.setDescription("**deletes a focused channel(cannot be undone, use with caution 'not recommended to test')** ")
 .addField("usage: $rmchannel, $delchannel, $deletechannel")
.setColor("RANDOM")
.setFooter("requires admin rights, because it's too scary for humanlings")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedchanneldel)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedchanneldel)
}
 }
  }
   });
 
   client.on('message', message => {
if(message.content === "$help ticketcreate") {
  let embedticket = new MessageEmbed()
.setTitle("Ticket Command: ")
.setDescription("**create a ticket for support(requires ticket channel id in ticket.js)** ")
.setColor("RANDOM")
.setFooter("usage $createticket, $newticket, $support")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedticket)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedticket)
}
 }
  }
   });
 
     //math commands
     client.on('message', message => {
    let embedmath = new MessageEmbed()
.setTitle("Math Commands: ")
.setDescription(" **add, sub, div, multi, expo, remainder, addmath, submath, multimath** ")
.setColor("RANDOM")
.setFooter("type $help <commandname> to see info on a specific command")
 if (message.guild) {
if(message.content === "$help math") {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedmath)
} else {
 if(message.content === "$help") {
  message.author.send(embedmath)
}  
 }
  }
   });
 
  client.on('message', message => {
if(message.content === "$help add") {
  let embedadd = new MessageEmbed()
.setTitle("Addition Command:")
.setDescription(" **adds two given numbers like a calculator** ")
.setColor("RANDOM")
.setFooter("usage: $add <num1> num2>")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedadd)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedadd)
}
 }
  }
   });
 
   client.on('message', message => {
if(message.content === "$help sub") {
  let embedsub = new MessageEmbed()
.setTitle("Subtraction Command:")
.setDescription(" **subtracts two given numbers like a calculator** ")
.setColor("RANDOM")
.setFooter("usage: $sub <num1> num2>")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedsub)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedsub)
}
 }
  }
   });
 
   client.on('message', message => {
if(message.content === "$help div") {
  let embeddiv = new MessageEmbed()
.setTitle("Division Command:")
.setDescription(" **divides two given numbers like a calculator** ")
.setColor("RANDOM")
.setFooter("usage: $div <num1> num2>")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embeddiv)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embeddiv)
}
 }
  }
   });

  client.on('message', message => {
if(message.content === "$help multi") {
  let embedmulti = new MessageEmbed()
.setTitle("Multiplication Command:")
.setDescription(" **multiplies two given numbers like a calculator** ")
.setColor("RANDOM")
.setFooter("usage: $multi <num1> num2>")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedmulti)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedmulti)
}
 }
  }
   });
   
   client.on('message', message => {
if(message.content === "$help expo") {
  let embedexpo = new MessageEmbed()
.setTitle("Exponent Command:")
.setDescription(" **gives the exponent of two given numbers like a calculator** ")
.setColor("RANDOM")
.setFooter("usage: $expo <num1> num2>")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedexpo)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedexpo)
}
 }
  }
   });
 
   client.on('message', message => {
if(message.content === "$help remain") {
  let embedremainder = new MessageEmbed()
.setTitle("Remainder Command:")
.setDescription(" **gives the remainder of two given numbers divided, like a calculator** ")
.setColor("RANDOM")
.setFooter("usage: $remain <num1> num2>")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedremainder)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedremainder)
}
 }
  }
   });

   client.on('message', message => {
if(message.content === "$help addmath") {
  let embedaddmath = new MessageEmbed()
.setTitle("Addition Problem Command:")
.setDescription(" **gives a random 1-100 addition problem that must be solved by the message author, times out after 30 seconds of inactivity** ")
.addField(" if you give up type stop to stop guessing ")
.setColor("RANDOM")
.setFooter("usage: $addmath")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedaddmath)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedaddmath)
}
 }
  }
   });
 
    client.on('message', message => {
if(message.content === "$help submath") {
  let embedsubmath = new MessageEmbed()
.setTitle("Subtraction game Command:")
.setDescription(" **gives a random 1-100 subtraction problem that must be solved by the message author, times out after 30 seconds of inactivity** ")
.addField(" if you give up type stop to stop guessing ")
.setColor("RANDOM")
.setFooter("usage: $submath")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedsubmath)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedsubmath)
}
 }
  }
   });
 
    client.on('message', message => {
if(message.content === "$help divmath") {
  let embeddivmath = new MessageEmbed()
.setTitle("Division game Command:")
.setDescription(" **gives a random 1-100 division problem that must be solved by the message author, times out after 30 seconds of inactivity** ")
.addField(" if you give up type stop to stop guessing ")
.setColor("RANDOM")
.setFooter("usage: $divmath")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embeddivmath)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embeddivmath)
}
 }
  }
   });
 
    client.on('message', message => {
if(message.content === "$help multimath") {
  let embedmultimath = new MessageEmbed()
.setTitle("Multiplication game Command:")
.setDescription(" **gives a random 1-100 multiplication problem that must be solved by the message author, times out after 30 seconds of inactivity** ")
.addField(" if you give up type stop to stop guessing ")
.setColor("RANDOM")
.setFooter("usage: $multimath")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedmultimath)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedmultimath)
}
 }
  }
   });
 
      //misc commands 
      client.on('message', message => {
  let embedmisc = new MessageEmbed()
.setTitle("Misc Commands:")
.setDescription("** rate10, rate100, random, date, time**")
.setColor("RANDOM")
.setFooter("type $help <commandname> to see info on a specific command")
 if (message.guild) {
if(message.content === "$help misc") {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
 if (message.guild) {
if(message.content === "$help misc") {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedmisc)
} else {
 if(message.content === "$help") {
message.author.send(embedmisc)
}
 }
  }
   });
 
      client.on('message', message => {
if(message.content === "$help random") {
  let embedrandom = new MessageEmbed()
.setTitle("Random number Command:")
.setDescription("**outputs a random number between 1 and 999**")
.setColor("RANDOM")
.setFooter("usage: $random, $randomnumber")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedrandom)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedrandom)
}
 }
  }
   });
 
      client.on('message', message => {
if(message.content === "$help rate100") {
  let embedrate100 = new MessageEmbed()
.setTitle("1-100 rating Command:")
.setDescription("**outputs a rating between 1 and 100**")
.setColor("RANDOM")
.setFooter("usage: $rate100, $100rate, $1-100")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedrate100)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedrate100)
}
 }
  }
   });
 
       client.on('message', message => {
if(message.content === "$help rate10") {
  let embedrate10 = new MessageEmbed()
.setTitle("1-10 rating Command:")
.setDescription("**outputs a rating between 1 and 100**")
.setColor("RANDOM")
.setFooter("usage: $rate10, $10rate, $1-10")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedrate10)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedrate10)
}
 }
  }
   });
 
       client.on('message', message => {
if(message.content === "$help date") {
  let embeddate = new MessageEmbed()
.setTitle("Date Command:")
.setDescription("**outputs the current local date and time(currently only available in whatever the servers' timezone is for now *:(* )**")
.setColor("RANDOM")
.setFooter("usage: $date, $getdate, $datetime")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embeddate)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embeddate)
}
 }
  }
   });
 
        client.on('message', message => {
if(message.content === "$help time") {
  let embedtime = new MessageEmbed()
.setTitle("Time Command:")
.setDescription("**outputs the current local time(currently only available in whatever the servers' timezone is for now *:(* )**")
.setColor("RANDOM")
.setFooter("usage: $time, $gettime, $clock")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedtime)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedtime)
}
 }
  }
   });
 
         client.on('message', message => {
if(message.content === "$help test") {
  let embedbpm = new MessageEmbed()
.setTitle("Test Command:")
.setDescription("**Test if the bot is working, outputs servers' local time and random heartbeat**")
.setColor("RANDOM")
.setFooter("usage: $test, $heartbeat, $bpm")
 if (message.guild) {
message.channel.send(`I sent you a dm with help ${message.author.tag}`)
message.author.send(embedbpm)
} else {
  if (!message.guild) {
  message.author.send(`Help is on the way`)
  message.author.send(embedbpm)
}
 }
  }
   });
 
  scalingChannels(client)
  
  const loadCommands = require('./load-commands.js')
  const baseFile = 'command-base.js'
  const commandBase = require(`./commands/${baseFile}`)

  const readCommands = (dir) => {
    const files = fs.readdirSync(path.join(__dirname, dir))
    for (const file of files) {
      const stat = fs.lstatSync(path.join(__dirname, dir, file))
      if (stat.isDirectory()) {
        readCommands(path.join(dir, file))
      } else if (file !== baseFile) {
        const option = require(path.join(__dirname, dir, file))
        commandBase(client, option)
}
 }
  }
  
  readCommands('commands')

client.login(BOT_TOKEN)
