const {MessageEmbed} = require('discord.js');
const { CommandoClient } = require('discord.js-commando');
module.exports = {
  commands: ['kick', 'sudo kick', 'boot'],
  minArgs: 0,
  maxArgs: 1,
  description: 'kick someone (requires kick permission)',
  permissionError: 'You do not have permission to use this command.',
  permissions: 'KICK_MEMBERS',
  callback: (message, userMessage, arguments, text, client) => {
    const { guild } = userMessage
if (!message.guild) {
return;
} else {
    const logchannel = message.guild.channels.cache.find(channel => channel.name === 'logs');
    if(message.mentions.users.size){
            const member = message.mentions.users.first()
        if(member){
        message.guild.member(member).kick({
        reason: 'They were disrespectful!',
         })
          .then(() => {
            message.channel.send(`Successfully kicked ${member.tag} `);
  message.delete();
   let embed = new MessageEmbed ()
 .setDescription("Kick Management")
    .setColor("#bc0000")
    .setImage("https://c.tenor.com/O_xuLx_lC-gAAAAC/stickman-smile.gif")
    .addField("Kicked User", `${member} with ID ${member.id}`)
    .addField("Kicked By", `<@${message.author.id}> with ID ${message.author.id}`)
    .addField("Kicked In", message.channel)
    .addField("Time", message.createdAt)
    logchannel.send(embed)

          })
          .catch(err => {
           if (!member) return message.channel.send ("I can't find this user");
            console.error(err);
          });
      } else {
         if (!message.member.hasPermission ("KICK_MEMBERS")) return message.channel.send ("You don't have permissions");
      }
    } else {
         if (member.hasPermission ("MANAGE_GUILD")) return message.channel.send ("This user cannot be kicked or banned");
         if (!logchannel) return message.channel.send ("I can't find the` logs` channel if it doesn't exist, please create it. ")
}
 }
  }
   }
module.exports.help = {
    name: "kick"
}
  return;
