const {MessageEmbed} = require('discord.js');
const { CommandoClient } = require('discord.js-commando');
module.exports = {
  commands: ['deletechannel', 'delchannel', 'rmchannel'],
  maxArgs: 0,
  description: 'delete a channel (use with caution)',
  permissionError: 'You must be an admin to use this command.',
  permissions: 'ADMINISTRATOR',
  callback: (message, userMessage, arguments, text, client) => {
    const { guild } = userMessage
    const channel = message.channel;
    const messageManager = channel.messages;
if (!message.guild) {
return;
} else {
   
   message.channel.send(` Are you sure you want to delete this channel ${message.author.id}? (yes or no)`);
   
   const logchannel = message.guild.channels.cache.find(channel => channel.name === 'logs');
   const maxWait = 30000; // in ms
    let embed = new MessageEmbed ()
    .setTitle("A Channel Has Been Deleted")
    .setDescription("Channel Management")
    .setColor("RANDOM")
    .addField("Deleted By", `<@${message.author.id}> with ID ${message.author.id}`)
    .addField("At", message.createdAt)
   
    const filter = (response) => response.author.id === message.author.id;
    const collector = message.channel.createMessageCollector(filter, {
    time: maxWait,
});
    
    collector.on('collect', (response) => {
    if (response.content === "no") 
  message.channel.messages.fetch({ limit: 3 }).then((results) => {
        message.channel.bulkDelete(results)
      })
    collector.stop();
     return;
 
    if (response.content === "yes") {
        message.channel.delete();
        logchannel.send(embed);
        collector.stop();
      } else {
    if (!response.content === "no") return;
    
    if (reason !== 'time') return;
}
  })
   }
    }
     }
