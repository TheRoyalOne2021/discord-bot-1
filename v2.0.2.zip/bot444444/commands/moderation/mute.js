module.exports = {
  commands: ['mute'],
  maxArgs: 1,
  description: 'mute someone (just assigns the mute role, mute role must already be configured by user)',
  permissionError: 'You do not have permission to use this command.',
  permissions: 'TIMEOUT_MEMBERS',
  callback: (message, arguments, text) => {
  if (!message.guild) return;
  const user = message.mentions.users.first();
  if (user) {
  const member = message.guild.members.resolve(user);
  var role= message.guild.roles.cache.find(role => role.name === "muted");
  member.roles.add(role);z
  message.channel.send(`Successfully muted ${user.tag} `);
}
 }
  }
