module.exports = {
  commands: ['random'],
  permissionError: 'You need more permissions to run this command',
  maxArgs: 0,
  permissions: 'SEND_MESSAGES',
  callback: (message, arguments, text) => {
  function getRandomNumber(min, max){
let randomNumber = getRandomNumber(0, 999999);
callback: (message, arguments, text) => {
    message.reply('${randomNumber')
  }
  }
  }
  }
