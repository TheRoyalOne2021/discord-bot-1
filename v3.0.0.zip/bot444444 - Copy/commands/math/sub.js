module.exports = {
  commands: ['sub', 'subtract', '-'],
  expectedArgs: '<num1> <num2>',
  permissionError: 'You need more permissions to run this command',
  minArgs: 2,
  maxArgs: 2,
  description: 'subtract two numbers',
  callback: (message, arguments, text) => {
    const num1 = +arguments[0]
    const num2 = +arguments[1]

    message.reply(`${num1} - ${num2} = ${num1 - num2}`)
  },
  permissions: 'SEND_MESSAGES',
  requiredRoles: [],
}

