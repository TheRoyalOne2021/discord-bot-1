module.exports = {
  commands: ['100rate', '1-100', 'rate100'],
  permissionError: 'You need more permissions to run this command',
  maxArgs: 0,
  description: 'let the bot give a 1-100 rating',
  permissions: 'SEND_MESSAGES',
  callback: (message, arguments, text) => {
var rate = Math.floor(Math.random() * 100) + 1;
  message.reply(` my rating is ${rate}/100 `);
 },
 }
