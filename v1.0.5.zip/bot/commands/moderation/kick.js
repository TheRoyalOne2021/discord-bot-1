module.exports = {
  commands: ['kick', 'boot'],
  maxArgs: 1,
  permissionError: 'You do not have permission to use this command.',
  permissions: 'KICK_MEMBERS',
  callback: (message, arguments, text) => {

  if (!message.guild) return;

    const user = message.mentions.users.first();

    if (user) {

      const member = message.guild.members.resolve(user);
      
      if (member) {
        member
          .kick({
            reason: 'They were disrespectful!',
          })
          .then(() => {
            message.channel.send(`Successfully kicked ${user.tag} `);
          })
          .catch(err => {
            message.channel.send('You do not have permissions to kick');
            console.error(err);
          });
      } else {
        message.channel.send("That user doesn't exist in this Guild!");
      }
    } else {
      message.channel.send("No user was mentioned!");
    }
}
}
