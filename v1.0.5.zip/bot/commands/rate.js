module.exports = {
  commands: ['rateme', 'rate'],
  permissionError: 'You need more permissions to run this command',
  maxArgs: 0,
  permissions: 'SEND_MESSAGES',
  callback: (message, arguments, text) => {
var rate = Math.floor(Math.random() * 100) + 1;
  message.reply(` my rating is ${rate}/100 `);
 },
 }
