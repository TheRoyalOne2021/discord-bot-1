const {Client, Intents, MessageEmbed} = require('discord.js');
const { CommandoClient } = require('discord.js-commando');
const client = new CommandoClient({
  intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MEMBERS, Intents.FLAGS.GUILD_MESSAGES],
});
module.exports = {
  commands: ['math1', 'addmath', 'mathadd', 'addproblem'],
  maxArgs: 0,
  description: 'gives a random 1-100 addition problem',
  permissionError: 'You do not have permission to use this command.',
  permissions: 'SEND_MESSAGES',
  callback: (message, arguments, text) => {
function randomInt(min, max) {
if (min > max) [min, max] = [max, min];
return Math.floor(Math.random() * (max - min + 1) + min);
}
  if (message.author.bot) return;
    const num1 = randomInt(0, 100);
    const num2 = randomInt(0, 100);
    const answer = num1 + num2;
    const maxWait = 30000; // in ms
    const embed = new MessageEmbed()
      .setColor('#f8cf4d')
      .setTitle(`Hey ${message.author.username}! What is ${num1} + ${num2}? 🙈`);
     message.channel.send(embed);
    const filter = (response) => response.author.id === message.author.id;
    const collector = message.channel.createMessageCollector(filter, {
      time: maxWait,
    });

    collector.on('collect', (response) => {
    if (response.content === "stop") message.channel.send(` game forfeited, you lose `);
    if (response.content === "stop") collector.stop();
      if (parseInt(response.content, 10) === answer) {
        message.channel.send(
          `🎉🎉🎉 Woohoo, ${response.author}! 🎉🎉🎉\n\nYou guessed The correct answer: \`${answer}\`.`,
);
        
        collector.stop();
      } else {
      if (response.content === "stop") return;
        message.channel.send(
          `Oh, ${response.author}, \`${response.content}\` is not correct... 🙊\nTry again.`,
        );
      }
    });

    collector.on('end', (collected, reason) => {
    
      if (reason !== 'time') return;

      if (collected.size > 0) {
        return message.channel.send(
          `Ah, ${message.author}. You guessed ${collected.size} time${
            collected.size > 1 ? 's' : ''
          } I am bored, the correct answer was: \`${answer}\`. I'm not saying you're stupid, but try harder next time...`,
        );
      }

      return message.channel.send(
        `Okay, ${message.author}, I'm bored and I can't wait any longer. No more answers are accepted. Respond faster next time...`,
      );
    });
  }
}
