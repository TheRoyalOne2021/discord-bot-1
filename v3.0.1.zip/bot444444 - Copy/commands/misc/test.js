module.exports = {
  commands: ['test', 'heartbeat', 'bpm'],
    permissions: 'SEND_MESSAGES',
  permissionError: 'You need more permissions to run this command',
  minArgs: 0,
  maxArgs: 0,
  description: 'test if the bot is working',
  callback: (message, arguments, text) => {
var bpm = Math.floor(Math.random() * 255) + 50;
var d = new Date();
   message.reply(`Last heartbeat recorded at ${(d.toLocaleString())} at ${bph}bpm`);
},
 };
