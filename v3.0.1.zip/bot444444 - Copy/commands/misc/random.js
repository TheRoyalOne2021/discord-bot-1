module.exports = {
  commands: ['random', 'randomnumber'],
  permissionError: 'You need more permissions to run this command',
  maxArgs: 0,
  description: 'fetch a random number between 1 and 999999',
  permissions: 'SEND_MESSAGES',
  callback: (message, arguments, text) => {
var random = Math.floor(Math.random() * 999) + 1;
  message.reply(` ${random} `);
 },
 }
