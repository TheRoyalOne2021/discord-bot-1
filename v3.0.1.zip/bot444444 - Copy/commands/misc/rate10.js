module.exports = {
  commands: ['10rate', '1-10', 'rate10'],
  permissionError: 'You need more permissions to run this command',
  maxArgs: 0,
  description: 'let the bot give a 1-10 rating',
  permissions: 'SEND_MESSAGES',
  callback: (message, arguments, text) => {
var rate = Math.floor(Math.random() * 10) + 1;
  message.reply(` my rating is ${rate}/10 `);
 },
 }
