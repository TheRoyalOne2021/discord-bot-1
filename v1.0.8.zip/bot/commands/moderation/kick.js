module.exports = {
  commands: ['kick', 'sudo kick', 'boot'],
  maxArgs: 1,
  description: 'kick someone (requires kick permission)',
  permissionError: 'You do not have permission to use this command.',
  permissions: 'KICK_MEMBERS',
  callback: (message, arguments, text) => {

  if (!message.guild) return;

    const user = message.mentions.users.first();

    if (user) {

      const member = message.guild.members.resolve(user);
      
      if (member) {
        member
          .kick({
            reason: 'They were disrespectful!',
          })
          .then(() => {
            message.channel.send(`Successfully kicked ${user.tag} `);
          })
          .catch(err => {
            message.channel.send('This member is either a bot or someone higher in power, i cannot kick them');
            console.error(err);
          });
      } else {
        message.channel.send("That user doesn't exist in this Guild!");
      }
    } else {
      message.channel.send("No user was mentioned!");
    }
}
}
