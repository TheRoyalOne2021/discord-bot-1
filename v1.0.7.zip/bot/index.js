const path = require('path')
const rpc = require('discord-rpc')
const fs = require('fs')
const config = require('./assets/config.json')
const env = require('./assets/.env')
const welcome = require('./assets/gifs/welcome-gifs.json')
const goodbye = require('./assets/gifs/goodbye-gifs.json')
const scalingChannels = require('./assets/scaling-channels')
const {Client, Intents, MessageEmbed} = require('discord.js');

const { CommandoClient } = require('discord.js-commando');
const client = new CommandoClient({
  intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MEMBERS, Intents.FLAGS.GUILD_MESSAGES],
});

client.setMaxListeners(0);

client.on('ready', () => {
    var a = new Date();
console.log(a.toLocaleString());
console.log('Bot successfully logged in!');

client.user.setPresence({
        status: 'online',
        activity: { 
            name: ` ${client.guilds.cache.size} servers`,
            details: 'https://discord.gg/5HeCfqfcj6',
            type: 'COMPETING',
            url: 'https://discord.gg/5HeCfqfcj6'
        }
    });
});

client.on('disconnect', (event) => {
  logger.error(`[DISCONNECT] Disconnected with code ${event.code}.`);
  process.exit(0);
});

client.on('error', (err) => logger.error(err));

client.on('message', message => {
const prefix = '!resetstatus';
    if (message.content.startsWith(prefix)) {
        if (message.member.hasPermission('ADMINISTRATOR')) {
client.user.setPresence({
        status: 'online',
        activity: { 
            name: ` ${client.guilds.cache.size} servers`,
            details: 'https://discord.gg/5HeCfqfcj6',
            type: 'COMPETING',
            url: 'https://discord.gg/5HeCfqfcj6'
}
 });
  }
   }
    });
    
    client.on('message', message => {
const prefix = '!setstatus';
    if (message.content.startsWith(prefix)) {
        const args = message.content.slice(prefix.length).trim(` ${message.content}`);
        if (message.member.hasPermission('ADMINISTRATOR')) {
        const presence = args;
client.user.setPresence({
        status: 'online',
        activity: { 
            name: ` ${presence} `,
            details: 'https://discord.gg/5HeCfqfcj6',
            type: 'PLAYING',
            url: 'https://discord.gg/5HeCfqfcj6'
}
 });
  }
   }
    });

client.on("message", message => {

if (message.content === "!servercount") {

const embed = new MessageEmbed()

.setTitle(` ${client.user.tag} is in ${client.guilds.cache.size} servers`)

.setDescription(`requested by ${message.author.tag}`)

.setTimestamp();

message.channel.send(embed);

}

});

client.on('guildMemberAdd', (member) => {
    console.log(member)
});

client.on('guildMemberAdd', member => {
var b = welcome[Math.floor(Math.random() * welcome.length)];
var serverIcon = member.guild.iconURL();
    const embed = new MessageEmbed()
      .setAuthor(['710615575419682848'].includes(client.user.id) ? 'Admin' : '')
      .setTitle(member.user.tag)
      .setDescription(' Welcome! Please Verify at #verify and check #rules ')
      .setThumbnail(serverIcon)
      .setImage(b)
      .setFooter(`Server: ${member.guild.name}`)
      if (['710615575419682848'].includes(client.user.id)) {
          embed.setColor('#ff0f00')
      } else {
          embed.setColor('RANDOM')
      }
      try {
       member.send(embed);
      } catch (e) {
        return;
      }
    });

client.on('guildMemberRemove', member => {
var c = goodbye[Math.floor(Math.random() * goodbye.length)];
    var serverIcon = member.guild.iconURL();
    const embed = new MessageEmbed()
      .setAuthor(['710615575419682848'].includes(client.user.id) ? 'Admin' : '')
      .setTitle(member.user.tag)
      .setDescription(' Goodbye :( sorry to see you leave so soon ')
      .setThumbnail(serverIcon)
      .setImage(c)
      .setFooter(`Server: ${member.guild.name}`)
      if (['710615575419682848'].includes(client.user.id)) {
          embed.setColor('#ff0f00')
      } else {
          embed.setColor('RANDOM')
      }
      try {
       member.send(embed);
      } catch (e) {
        return;
      }
    });

  scalingChannels(client)
  
  const loadCommands = require('./load-commands.js')
  const baseFile = 'command-base.js'
  const commandBase = require(`./commands/${baseFile}`)

  const readCommands = (dir) => {
    const files = fs.readdirSync(path.join(__dirname, dir))
    for (const file of files) {
      const stat = fs.lstatSync(path.join(__dirname, dir, file))
      if (stat.isDirectory()) {
        readCommands(path.join(dir, file))
      } else if (file !== baseFile) {
        const option = require(path.join(__dirname, dir, file))
        commandBase(client, option)
      }
    }
  }
  
  readCommands('commands')

client.login(BOT_TOKEN)
