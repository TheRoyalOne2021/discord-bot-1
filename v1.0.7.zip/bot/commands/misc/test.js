module.exports = {
  commands: ['test', 'hello'],
    permissions: 'SEND_MESSAGES',
  permissionError: 'You need more permissions to run this command',
  minArgs: 0,
  maxArgs: 0,
  description: 'test if the bot is working',
  callback: (message, arguments, text) => {
var d = new Date();
   message.reply(`Last heartbeat recorded at ${(d.toLocaleString())}; `);
    },
};
