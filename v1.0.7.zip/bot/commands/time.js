module.exports = {
  commands: ['time', 'clock'],
    permissions: 'SEND_MESSAGES',
  permissionError: 'You need more permissions to run this command',
  minArgs: 0,
  maxArgs: 0,
  description: 'show the current time "EST only for now" ',
  callback: (message, arguments, text) => {
   var time = new Date();
var Hour = time.getHours();
var AMPM = Hour >= 12 ? 'PM' : 'AM';
var Minute = time.getMinutes();
var Second = time.getSeconds();
Hour = (Hour % 12) || 12;
Minute = Minute < 10 ? '0'+Minute : Minute;
Second = Second < 10 ? '0'+Second : Second;
   message.reply(`Time: ${Hour}:${Minute}:${Second} ${AMPM} `);
    },
};
