module.exports = {
  commands: ['deletechannel', 'delchannel', 'rmchannel'],
  maxArgs: 0,
  description: 'delete a channel (use with caution)',
  permissionError: 'You must be an admin to use this command.',
  permissions: 'ADMINISTRATOR',
  callback: (message, arguments, text) => {
    message.channel.delete()
  },
}
