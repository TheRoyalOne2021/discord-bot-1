module.exports = {
  commands: ['clear', 'clearchannel', 'cc', 'sudo apt clean'],
  maxArgs: 0,
  description: 'mass delete messages in a channel (use with caution)',
  permissionError: 'You must be a mod to use this command.',
  permissions: 'MANAGE_MESSAGES',
  callback: (message, arguments, text) => {
      message.channel.messages.fetch().then((results) => {
        message.channel.bulkDelete(results)
      })
  }
  }
