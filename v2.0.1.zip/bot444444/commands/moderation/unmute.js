module.exports = {
  commands: ['unmute'],
  maxArgs: 1,
  description: 'unmute someone',
  permissionError: 'You do not have permission to use this command.',
  permissions: 'TIMEOUT_MEMBERS',
  callback: (message, arguments, text) => {
  if (!message.guild) return;
  const user = message.mentions.users.first();
  if (user) {
  const member = message.guild.members.resolve(user);
  var role= message.guild.roles.cache.find(role => role.name === "muted");
  member.roles.remove(role);
  message.channel.send(`Successfully unmuted ${user.tag} `);
}
 }
  }
