const {MessageEmbed} = require('discord.js');
const { CommandoClient } = require('discord.js-commando');
module.exports = {
  commands: ['avatar', 'pfp'],
    permissions: 'SEND_MESSAGES',
  permissionError: 'You need more permissions to run this command',
  maxArgs: 1,
  cooldown: 1,
  description: 'fetch an avatar',
  callback: (message, arguments, text) => {
     
   if (!message.guild) return;
   
   if(message.mentions.users.size){
            const member = message.mentions.users.first()
        if(member){
            const embed = new MessageEmbed()
            .setImage(member.displayAvatarURL(({ dynamic: true, size: 256})))
            .setTitle(member.tag)
            .setColor('RANDOM')
            .addField("Requested By", `<@${message.author.id}> `)
            message.channel.send(embed)
} else {
            message.channel.send("That user doesn't exist in this Guild!")
}
 } else {
            const embed = new MessageEmbed()
            .setImage(message.author.displayAvatarURL(({ dynamic: true, size: 256})))
            .setTitle(message.author.tag)
            .setColor('RANDOM')
            .addField("Requested By", `<@${message.author.id}> `)
            message.channel.send(embed)
}
 }
  }
