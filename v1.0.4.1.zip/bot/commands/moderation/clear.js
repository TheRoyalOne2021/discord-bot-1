module.exports = {
  commands: ['clear', 'clearchannel', 'cc'],
  maxArgs: 0,
  permissionError: 'You must be a mod to use this command.',
  permissions: 'MANAGE_MESSAGES',
  callback: (message, arguments, text) => {
      message.channel.messages.fetch().then((results) => {
        message.channel.bulkDelete(results)
      })
  }
  }
