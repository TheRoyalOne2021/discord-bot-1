module.exports = {
  commands: ['status', 'setstatus', 'rp'],
  maxArgs: 1,
  permissionError: 'You must be a mod to use this command.',
  permissions: 'MANAGE_GUILD',
  callback: (message, arguments, text) => {
    const content = message.content.replace('!status ', '')
    // "!status hello world" -> "hello world"

    client.user.setPresence({
      activity: {
        name: content,
        type: 0,
      }
    })
}
}
