module.exports = {
  commands: ['test', 'hello'],
  permissionError: 'You need more permissions to run this command',
  minArgs: 0,
  maxArgs: 0,
  callback: (message, arguments, text) => {

   message.reply('hello!')
  },
  permissions: 'SEND_MESSAGES',
  requiredRoles: [],
}

